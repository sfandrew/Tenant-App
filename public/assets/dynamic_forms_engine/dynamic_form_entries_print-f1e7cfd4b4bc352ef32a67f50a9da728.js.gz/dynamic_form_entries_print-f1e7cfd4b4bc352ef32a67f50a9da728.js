window.print();
